animals = ['bear', 'tiger', 'penguin', 'zebra']
bear = animals[0]

