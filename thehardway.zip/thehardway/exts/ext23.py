#command-line-chess in python3, but failed to read.


